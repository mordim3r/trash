
//https://www.youtube.com/watch?v=xf_gWb_dm30


const cardsArr = [
    {imageName: 'img-1', imagePath: 'img/img-1.png'},
    {imageName: 'img-2', imagePath: 'img/img-2.png'},
    {imageName: 'img-3', imagePath: 'img/img-3.png'},
    {imageName: 'img-4', imagePath: 'img/img-4.png'},
    {imageName: 'img-5', imagePath: 'img/img-5.png'},
    {imageName: 'img-6', imagePath: 'img/img-6.png'},
    {imageName: 'img-1', imagePath: 'img/img-1.png'},
    {imageName: 'img-2', imagePath: 'img/img-2.png'},
    {imageName: 'img-3', imagePath: 'img/img-3.png'},
    {imageName: 'img-4', imagePath: 'img/img-4.png'},
    {imageName: 'img-5', imagePath: 'img/img-5.png'},
    {imageName: 'img-6', imagePath: 'img/img-6.png'},
]



//выполнить сортировку в случайном порядке
//передать функцию сравнения compare function
cardsArr.sort(function(){return 0.5 - Math.random()})
console.log(cardsArr)

//обращение к элементам страницы по тегам спан и див
const span = document.querySelector('#span')
const cardsDiv = document.querySelector('.cardsDiv')
const messageDiv = document.querySelector('.messageDiv')

//сщздаем поле из карточек
function createBoard(){
    //срздать 12 тегов внутри блока cardsDiv
    //типа
    //<img id='счетчик' src='картинка' onclick='flipCard'>
    for (let i=0; i<cardsArr.length; i++){
        const imgCard = document.createElement('IMG')
        imgCard.setAttribute('id', String(i))
        imgCard.setAttribute('src', 'img/1.jpg')
        imgCard.addEventListener('click', flipCard)
        cardsDiv.appendChild(imgCard)
        console.log(imgCard)
        console.log('createBoard')

    }
}
createBoard()


//массив выбранных карточек, их идентификаторов, массив для числа выбранных карточек
let cardsChosenArr=[]
let cardsChosenArrId=[]
let nOfOpenedcarsArr=[]


//проверка соответствий карточек
function CheckForMatch(){
    //массив всех изображений на странице
    //cards [0: img#0, 1: img#1, ...]
    const cards = document.querySelectorAll('img')
    //идентификатор первогои второго выбранного изображения
    const id1 = cardsChosenArrId[0]
    const id2 = cardsChosenArrId[1]
    //найдено соответствие и пользователь не кликнул по одной и той же карточке
    if(cardsChosenArr[0]===cardsChosenArr[1] && id1 !== id2){
        messageDiv.innerHTML = 'Match found!'
        cards[id1].setAttribute('src', 'img/image_found.png')
        cards[id2].setAttribute('src', 'img/image_found.png')
        //удалить с карточки онклик
        cards[id1].removeEventListener('click', flipCard)
        cards[id2].removeEventListener('click', flipCard)
        nOfOpenedcarsArr.push(cardsChosenArr)
        //пользователь совершил клик по одной каточке
        //карточки не совпали
    }  else{
        cards[id1].setAttribute('src', 'img/image_blank.png')
        cards[id2].setAttribute('src', 'img/image_blank.png')
        messageDiv.innerHTML='Chosen the same cards or do not match, select another!'
    }

    cardsChosenArr =[]
    cardsChosenArrId=[]
//вывести в спан количество открытых карточек
    span.textContent = String(nOfOpenedcarsArr.length)
    //если количество открытых равно половине от их общего числа выдать сообщение о победе
    if(nOfOpenedcarsArr.length === cards.length / 2){
        messageDiv.innerHTML = 'You won'
    }
}

function flipCard(){
    let cardID = this.getAttribute('id')
    //записать имя изображения
    cardsChosenArr.push(cardsArr[cardID].imageName)
    cardsChosenArrId.push(cardID)
    //записать в src путь к файлу с изображением
    this.setAttribute('src', cardsArr[cardID].imagePath)
    //задержка выбора карточки 1c
    if(cardsChosenArr.length === 2){
        setTimeout(CheckForMatch, 1000)
    }
}
//flipCard()

